create database islisko_19 default character set utf8;
use islisko_19;
create table izvedba(
    sifra int not null primary key auto_increment,
    izvodac varchar(255) not null,
    simfonijski_orkestar varchar(255) not null,
    nalaziSeU varchar(255) not null,
    dobilaJe varchar(255) not null,
    brojIzvedbi int not null,
    mjesec varchar(255) not null
);
