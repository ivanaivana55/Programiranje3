<?php

namespace Slisko;

/**
 * @Entity @Table(name="izvedba")
 **/


class Ontologija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $izvodac;

    /**
    * @Column(type="string")
    */
    private $simfonijski_orkestar;

    /**
    * @Column(type="string")
    */
    private $nalaziSeU;

    /**
    * @Column(type="string")
    */
    private $dobilaJe;

    /**
    * @Column(type="integer")
    */
    private $brojIzvedbi;

    /**
    * @Column(type="string")
    */
    private $mjesec;

  public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

  public function getIzvodac(){
    return $this->izvodac;
  }

  public function setIzvodac($izvodac){
		$this->izvodac = $izvodac;
	}

  public function getSimfonijskiOrkestar(){
  	return $this->simfonijski_orkestar;
  }

  public function setSimfonijskiOrkestar($simfonijski_orkestar){
		$this->simfonijski_orkestar = $simfonijski_orkestar;
	}

  public function getNalaziSeU(){
    return $this->nalaziSeU;
  }

  public function setNalaziSeU($nalaziSeU){
    $this->nalaziSeU = $nalaziSeU;
  }

  public function getDobilaJe(){
    return $this->dobilaJe;
  }

  public function setDobilaJe($dobilaJe){
    $this->dobilaJe = $dobilaJe;
  }

  public function getBrojIzvedbi(){
    return $this->brojIzvedbi;
  }

  public function setBrojIzvedbi($brojIzvedbi){
    $this->brojIzvedbi = $brojIzvedbi;
  }

  public function getMjesec(){
    return $this->mjesec;
  }

  public function setMjesec($mjesec){
    $this->mjesec = $mjesec;
  }

  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
