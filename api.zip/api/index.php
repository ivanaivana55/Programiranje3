<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Slisko\Ontologija;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){
  $foaf = \EasyRdf\Graph::newAndLoad('http://oziz.ffos.hr/nastava20192020/islisko_19/ontologija/izvedba_slisko.rdf');
  echo $foaf->dump();
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Slisko\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});

Flight::route('GET /search/@izvodac', function($izvodac){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Slisko\Ontologija');
  $zapisi = $repozitorij->createQueryBuilder('i')
           ->where('i.izvodac LIKE :izvodac')
           ->setParameter('izvodac', '%'.$izvodac.'%')
            ->getQuery()
            ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

Flight::route('GET /popunibazu', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('http://oziz.ffos.hr/nastava20192020/islisko_19/ontologija/izvedba_slisko.rdf');


  foreach ($foaf->resources() as $resource) {

    if($foaf->get($resource, 'rdf:type') != ''){
      $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/islisko/izvedba#izvodac>'));
      $izvodac = str_replace('_', ' ', $url["fragment"]);
      $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/islisko/izvedba#simfonijski_orkestar>'));
      $simfonijski_orkestar = str_replace('_', ' ', $url["fragment"]);
      $nalaziSeU = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw2/cepcar-slisko/izinkg-ontologija#nalaziseU>');
      $dobilaJe = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw2/cepcar-slisko/izinkg-ontologija#dobilaJe>');
      $brojIzvedbi = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw2/islisko/izvedba#broj_izvedbi>');
      $mjesec = $foaf->get($resource, '<http://oziz.ffos.hr/tsw2/islisko/izvedba#vrijeme>');

      $ontologija = new Ontologija();
      $ontologija->setPodaci(Flight::request()->data);

      $ontologija->setIzvodac($izvodac);
      $ontologija->setSimfonijskiOrkestar($simfonijski_orkestar);
      $ontologija->setNalaziSeU($nalaziSeU);
      $ontologija->setDobilaJe($dobilaJe);
      $ontologija->setBrojIzvedbi($brojIzvedbi);
      $ontologija->setMjesec($mjesec);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($ontologija);
      $em->flush();

      }

  }

});



$cl = new ClassLoader('Slisko', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();
